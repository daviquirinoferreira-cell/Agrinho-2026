// Variáveis para armazenar as imagens
let imagemJogador;
let imagemObjeto;

// Variáveis do Jogador (Cesta)
let jogadorX;
let jogadorY;
let jogadorLargura = 80;
let jogadorAltura = 50; // Ajustado para se adequar melhor a uma imagem

// Variáveis do Objeto (Maçã)
let objetoX;
let objetoY = 0;
let objetoTamanho = 40; // Ajustado para o tamanho da imagem
let velocidadeObjeto = 4;

// Variáveis de Estado do Jogo
let pontuacao = 0;
let jogoTerminado = false;

// 1. FUNÇÃO PRELOAD: Carrega as imagens antes do jogo iniciar
function preload() {
  // ATENÇÃO: Substitui pelos nomes exatos dos teus ficheiros que enviaste para o editor!
  imagemJogador = loadImage('Cesta.png'); 
  imagemObjeto = loadImage('Maca.png');
}

function setup() {
  createCanvas(400, 400);
  jogadorX = width / 2 - jogadorLargura / 2;
  jogadorY = height - 60; // Ajustada a posição vertical por causa do novo tamanho
  reiniciarObjeto();
}

function draw() {
  background(220); // Podes substituir por uma imagem de fundo também!

  if (jogoTerminado) {
    exibirTelaGameOver();
  } else {
    atualizarJogo();
  }
}

function atualizarJogo() {
  // Movimentar o Jogador
  if (keyIsDown(LEFT_ARROW) && jogadorX > 0) {
    jogadorX -= 6;
  }
  if (keyIsDown(RIGHT_ARROW) && jogadorX < width - jogadorLargura) {
    jogadorX += 6;
  }

  // 2. DESENHAR A IMAGEM DO JOGADOR
  // Parâmetros: image(variável, x, y, largura, altura)
  image(imagemJogador, jogadorX, jogadorY, jogadorLargura, jogadorAltura);

  // Movimentar o Objeto
  objetoY += velocidadeObjeto;

  // 3. DESENHAR A IMAGEM DO OBJETO (Maçã)
  image(imagemObjeto, objetoX, objetoY, objetoTamanho, objetoTamanho);

  // Verificar Colisão com a Cesta
  if (objetoY + objetoTamanho >= jogadorY && 
      objetoX + objetoTamanho/2 >= jogadorX && 
      objetoX + objetoTamanho/2 <= jogadorX + jogadorLargura) {
    pontuacao += 10;
    velocidadeObjeto += 0.5;
    reiniciarObjeto();
  }

  // Verificar se o Objeto caiu no chão
  if (objetoY > height) {
    jogoTerminado = true;
  }

  // Exibir Pontuação
  fill(0);
  textSize(20);
  text("Pontos: " + pontuacao, 20, 30);
}

function reiniciarObjeto() {
  // Garante que o objeto surge totalmente dentro do ecrã
  objetoX = random(0, width - objetoTamanho);
  objetoY = -objetoTamanho; // Começa um pouco acima do ecrã para uma transição suave
}

function exibirTelaGameOver() {
  fill(255, 0, 0);
  textSize(32);
  textAlign(CENTER, CENTER);
  text("GAME OVER", width / 2, height / 2 - 20);
  
  fill(0);
  textSize(16);
  text("Pontuação Final: " + pontuacao, width / 2, height / 2 + 20);
  text("Pressiona R para reiniciar", width / 2, height / 2 + 50);
}

function keyPressed() {
  if (jogoTerminado && (key === 'r' || key === 'R')) {
    pontuacao = 0;
    velocidadeObjeto = 4;
    jogoTerminado = false;
    reiniciarObjeto();
    jogadorX = width / 2 - jogadorLargura / 2;
  }
}